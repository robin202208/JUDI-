export const CONFIG = {
  OPENAI_API_KEY: import.meta.env.VITE_OPENAI_API_KEY || 'sk-JYlLDC7JhTcs9KbR49D639EeCe134169Bc081aEb9eF6751d',
  API_BASE_URL: import.meta.env.VITE_API_BASE_URL || 'https://api.aihubmix.com',
  BACKUP_API_URL: 'https://api.aihubmix.com',
  LEGAL_API_URL: 'https://abc.shengudata.com/api/v1',
  LEGAL_API_KEY: 'openapi-vkfmyIcakqFtMB5qsavGaRfWcLZ1vuG1eN3ETYhzkFi2CC1YhDOCHcoHWB',
  MODEL: 'gpt-3.5-turbo',
  MAX_RETRIES: 3,
  RETRY_DELAY: 1000,
  REQUEST_TIMEOUT: 30000,
};

export const ERROR_MESSAGES = {
  QUOTA_EXCEEDED: '配额不足，请检查您的API额度',
  INVALID_API_KEY: 'API密钥无效',
  NETWORK_ERROR: '网络连接错误，请稍后重试',
  UNKNOWN_ERROR: '发生未知错误，请稍后重试',
  SERVER_ERROR: '服务器错误，正在切换备用服务器',
  API_UNAVAILABLE: '主服务器不可用，已切换至备用服务器',
};

export const MODELS = {
  GENERAL: 'general',
  LEGAL: 'legal'
} as const;

export type ModelType = typeof MODELS[keyof typeof MODELS];