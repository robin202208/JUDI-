import axios from 'axios';
import { CONFIG } from '../config/env';

const legalApi = axios.create({
  baseURL: CONFIG.LEGAL_API_URL,
  headers: {
    'Authorization': `Bearer ${CONFIG.LEGAL_API_KEY}`,
    'Content-Type': 'application/json',
  },
  timeout: CONFIG.REQUEST_TIMEOUT,
});

export const sendLegalQuery = async (query: string): Promise<string> => {
  try {
    const response = await legalApi.post('/chat/completions', {
      model: "gpt-3.5-turbo",
      messages: [{
        role: 'user',
        content: `[法律咨询] ${query}`
      }],
      temperature: 0.7,
      max_tokens: 2000
    });

    if (response.data?.choices?.[0]?.message?.content) {
      return response.data.choices[0].message.content;
    }

    if (response.data?.response) {
      return response.data.response;
    }

    if (typeof response.data === 'string') {
      return response.data;
    }

    throw new Error('无法解析API响应');
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('Legal API Error:', {
        status: error.response?.status,
        data: error.response?.data,
        headers: error.response?.headers
      });
      
      const errorMessage = 
        error.response?.data?.error?.message ||
        error.response?.data?.message ||
        error.message ||
        '法律助手服务暂时不可用，请稍后重试';
      
      throw new Error(errorMessage);
    }
    throw error;
  }
};