import { AxiosError, AxiosInstance } from 'axios';
import { CONFIG, ERROR_MESSAGES } from '../config/env';
import { primaryApi, backupApi } from './apiConfig';

let currentApi = primaryApi;

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const handleApiError = (error: AxiosError) => {
  const errorData = error.response?.data as any;
  
  if (errorData?.error?.code === 'insufficient_user_quota') {
    throw new Error(ERROR_MESSAGES.QUOTA_EXCEEDED);
  }
  
  if (error.response?.status === 401) {
    throw new Error(ERROR_MESSAGES.INVALID_API_KEY);
  }
  
  if (error.code === 'ECONNABORTED' || error.code === 'NETWORK_ERROR') {
    throw new Error(ERROR_MESSAGES.NETWORK_ERROR);
  }
  
  throw new Error(errorData?.error?.message || ERROR_MESSAGES.UNKNOWN_ERROR);
};

const tryRequest = async <T>(
  apiInstance: AxiosInstance,
  request: () => Promise<T>
): Promise<T> => {
  try {
    return await request();
  } catch (error) {
    if (apiInstance === primaryApi && error instanceof AxiosError) {
      console.log('Primary API failed, switching to backup');
      currentApi = backupApi;
      throw new Error(ERROR_MESSAGES.API_UNAVAILABLE);
    }
    throw error;
  }
};

export const sendMessage = async (messages: { role: 'user' | 'assistant'; content: string }[]) => {
  let retries = 0;
  
  while (retries < CONFIG.MAX_RETRIES) {
    try {
      const response = await tryRequest(currentApi, () =>
        currentApi.post('/v1/chat/completions', {
          model: CONFIG.MODEL,
          messages,
          temperature: 0.7,
          max_tokens: 1000,
        })
      );

      if (response.data.choices?.[0]?.message?.content) {
        return response.data.choices[0].message.content;
      }
      
      throw new Error('Invalid response format from API');
    } catch (error) {
      if (error instanceof AxiosError) {
        if (retries === CONFIG.MAX_RETRIES - 1) {
          handleApiError(error);
        }
        
        await sleep(CONFIG.RETRY_DELAY * (retries + 1));
        retries++;
        continue;
      }
      
      if (error instanceof Error && error.message === ERROR_MESSAGES.API_UNAVAILABLE) {
        // Reset retry count when switching to backup API
        retries = 0;
        continue;
      }
      
      throw error;
    }
  }
  
  throw new Error(ERROR_MESSAGES.UNKNOWN_ERROR);
};

export const checkApiStatus = async () => {
  try {
    await tryRequest(currentApi, () => currentApi.get('/v1/models'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message === ERROR_MESSAGES.API_UNAVAILABLE) {
      // Try again with backup API
      try {
        await tryRequest(backupApi, () => backupApi.get('/v1/models'));
        return true;
      } catch (error) {
        if (error instanceof AxiosError) {
          handleApiError(error);
        }
        return false;
      }
    }
    if (error instanceof AxiosError) {
      handleApiError(error);
    }
    return false;
  }
};