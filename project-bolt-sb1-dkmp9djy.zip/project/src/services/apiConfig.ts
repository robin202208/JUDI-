import axios from 'axios';
import { CONFIG } from '../config/env';

export const createApiInstance = (baseURL: string) => {
  return axios.create({
    baseURL,
    headers: {
      'Authorization': `Bearer ${CONFIG.OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
    },
    timeout: CONFIG.REQUEST_TIMEOUT,
  });
};

export const primaryApi = createApiInstance(CONFIG.API_BASE_URL);
export const backupApi = createApiInstance(CONFIG.BACKUP_API_URL);