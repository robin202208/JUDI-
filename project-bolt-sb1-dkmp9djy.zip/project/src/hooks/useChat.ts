import { useState, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useChatStore } from '../store/chatStore';
import { sendMessage, checkApiStatus } from '../services/api';
import { sendLegalQuery } from '../services/legalApi';
import { Message } from '../types/chat';
import { MODELS, ModelType } from '../config/env';

export const useChat = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { currentConversation, addMessage } = useChatStore();

  const verifyApiConnection = useCallback(async () => {
    try {
      return await checkApiStatus();
    } catch (error) {
      return false;
    }
  }, []);

  const sendMessageToAI = async (content: string, modelType: ModelType = MODELS.GENERAL) => {
    if (!currentConversation) return;

    const userMessage: Message = {
      id: uuidv4(),
      content,
      role: 'user',
      timestamp: Date.now(),
    };

    addMessage(currentConversation.id, userMessage);
    setIsLoading(true);

    try {
      let aiResponse: string;

      if (modelType === MODELS.LEGAL) {
        try {
          aiResponse = await sendLegalQuery(content);
        } catch (error) {
          console.error('Legal API Error:', error);
          throw new Error(error instanceof Error ? error.message : '法律助手服务暂时不可用，请稍后重试');
        }
      } else {
        const isApiAvailable = await verifyApiConnection();
        if (!isApiAvailable) {
          throw new Error('API服务不可用，请稍后重试');
        }

        const updatedConversation = useChatStore.getState().conversations
          .find(conv => conv.id === currentConversation.id);
        
        if (!updatedConversation) {
          throw new Error('会话不存在');
        }

        const messages = updatedConversation.messages.map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

        aiResponse = await sendMessage(messages);
      }

      const aiMessage: Message = {
        id: uuidv4(),
        content: aiResponse,
        role: 'assistant',
        timestamp: Date.now(),
      };

      addMessage(currentConversation.id, aiMessage);
    } catch (error) {
      const errorMessage: Message = {
        id: uuidv4(),
        content: error instanceof Error ? error.message : '获取AI响应时发生错误，请重试。',
        role: 'assistant',
        timestamp: Date.now(),
      };
      addMessage(currentConversation.id, errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    sendMessage: sendMessageToAI,
    verifyApiConnection,
  };
};