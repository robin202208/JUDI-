import { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useChatStore } from '../store/chatStore';
import { sendLegalQuery } from '../services/legalApi';
import { Message } from '../types/chat';

export const useLegalChat = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { currentConversation, addMessage } = useChatStore();

  const sendLegalMessage = async (content: string) => {
    if (!currentConversation) return;

    const userMessage: Message = {
      id: uuidv4(),
      content,
      role: 'user',
      timestamp: Date.now(),
    };

    addMessage(currentConversation.id, userMessage);
    setIsLoading(true);

    try {
      const response = await sendLegalQuery(content);
      
      const aiMessage: Message = {
        id: uuidv4(),
        content: response,
        role: 'assistant',
        timestamp: Date.now(),
      };

      addMessage(currentConversation.id, aiMessage);
    } catch (error) {
      const errorMessage: Message = {
        id: uuidv4(),
        content: error instanceof Error ? error.message : '获取法律咨询响应时发生错误，请重试。',
        role: 'assistant',
        timestamp: Date.now(),
      };
      addMessage(currentConversation.id, errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    sendMessage: sendLegalMessage,
  };
};