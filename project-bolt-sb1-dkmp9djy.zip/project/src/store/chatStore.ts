import { create } from 'zustand';
import { Conversation, Message } from '../types/chat';

interface ChatState {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  addConversation: (conversation: Conversation) => void;
  setCurrentConversation: (conversation: Conversation) => void;
  addMessage: (conversationId: string, message: Message) => void;
}

export const useChatStore = create<ChatState>((set) => ({
  conversations: [],
  currentConversation: null,
  addConversation: (conversation) =>
    set((state) => ({
      conversations: [...state.conversations, conversation],
      currentConversation: conversation,
    })),
  setCurrentConversation: (conversation) =>
    set({ currentConversation: conversation }),
  addMessage: (conversationId, message) =>
    set((state) => {
      const updatedConversations = state.conversations.map((conv) =>
        conv.id === conversationId
          ? {
              ...conv,
              messages: [...conv.messages, message],
              updatedAt: Date.now(),
            }
          : conv
      );

      const updatedCurrentConversation = updatedConversations.find(
        (conv) => conv.id === conversationId
      ) || null;

      return {
        conversations: updatedConversations,
        currentConversation: updatedCurrentConversation,
      };
    }),
}));