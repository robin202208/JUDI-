import React from 'react';
import { RadioGroup } from '@headlessui/react';
import { MODELS, ModelType } from '../config/env';
import clsx from 'clsx';

interface ModelSelectorProps {
  selectedModel: ModelType;
  onChange: (model: ModelType) => void;
}

export const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onChange }) => {
  const models = [
    { id: MODELS.GENERAL, name: 'JUDI 智能助手', description: '通用AI对话助手' },
    { id: MODELS.LEGAL, name: '法律助手', description: '专业法律咨询助手' },
  ];

  return (
    <RadioGroup value={selectedModel} onChange={onChange} className="mt-2">
      <div className="grid grid-cols-2 gap-3 p-2">
        {models.map((model) => (
          <RadioGroup.Option
            key={model.id}
            value={model.id}
            className={({ checked }) =>
              clsx(
                'cursor-pointer rounded-xl p-4 transition-all duration-300',
                'border focus:outline-none',
                checked
                  ? 'bg-gradient-to-r from-blue-600/90 to-blue-700/90 text-white border-blue-500'
                  : 'bg-gray-800/50 text-gray-300 border-blue-500/20 hover:bg-gray-800/70'
              )
            }
          >
            {({ checked }) => (
              <div className="flex flex-col">
                <RadioGroup.Label
                  className={clsx(
                    'font-medium',
                    checked ? 'text-white' : 'text-blue-200'
                  )}
                >
                  {model.name}
                </RadioGroup.Label>
                <RadioGroup.Description
                  className={clsx(
                    'text-sm',
                    checked ? 'text-blue-100' : 'text-gray-400'
                  )}
                >
                  {model.description}
                </RadioGroup.Description>
              </div>
            )}
          </RadioGroup.Option>
        ))}
      </div>
    </RadioGroup>
  );
};