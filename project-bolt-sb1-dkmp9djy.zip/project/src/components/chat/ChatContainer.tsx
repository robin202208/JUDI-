import React from 'react';
import { MessageList } from './MessageList';
import { ChatInput } from './ChatInput';
import { ModelSelector } from '../ModelSelector';
import { Message } from '../../types/chat';
import { ModelType } from '../../config/env';

interface ChatContainerProps {
  messages: Message[];
  isLoading: boolean;
  selectedModel: ModelType;
  onModelChange: (model: ModelType) => void;
  onSendMessage: (content: string) => void;
}

export const ChatContainer: React.FC<ChatContainerProps> = ({
  messages,
  isLoading,
  selectedModel,
  onModelChange,
  onSendMessage,
}) => {
  return (
    <>
      <div className="p-4 bg-gradient-to-b from-gray-900/50 to-transparent">
        <ModelSelector
          selectedModel={selectedModel}
          onChange={onModelChange}
        />
      </div>
      <MessageList 
        messages={messages} 
        isLoading={isLoading} 
      />
      <ChatInput 
        onSendMessage={onSendMessage}
        disabled={isLoading}
        placeholder={
          selectedModel === 'legal'
            ? "请输入您的法律问题..."
            : "输入您的问题..."
        }
      />
    </>
  );
};