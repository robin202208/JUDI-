import React from 'react';
import { Bars3Icon } from '@heroicons/react/24/outline';

interface HeaderProps {
  onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <button
              onClick={onMenuClick}
              className="mr-4 p-2 rounded-lg hover:bg-blue-700 md:hidden"
            >
              <Bars3Icon className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-3 md:space-x-4">
              <img src="/logo.png" alt="JUDI" className="h-8 w-auto md:h-10" />
              <div>
                <h1 className="text-lg md:text-xl font-bold truncate">上海九地之下技术有限公司</h1>
                <p className="text-xs md:text-sm text-blue-100">JUDI 智能对话系统</p>
              </div>
            </div>
          </div>
          <div className="flex items-center">
            <span className="hidden md:block px-4 py-1.5 bg-blue-500 text-white rounded-full text-sm font-medium border border-blue-400">
              JUDI 大模型
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};