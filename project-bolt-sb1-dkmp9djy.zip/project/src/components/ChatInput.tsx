import React, { useState } from 'react';
import clsx from 'clsx';

interface ChatInputProps {
  onSendMessage: (content: string) => void;
  disabled?: boolean;
  placeholder?: string;
}

export const ChatInput: React.FC<ChatInputProps> = ({ 
  onSendMessage, 
  disabled,
  placeholder = "输入您的问题..." 
}) => {
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <div className="sticky bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-gray-900 to-transparent">
      <div className="max-w-4xl mx-auto">
        <form onSubmit={handleSubmit} className="relative flex items-center gap-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={placeholder}
            disabled={disabled}
            className={clsx(
              "w-full p-4 pr-12 rounded-xl",
              "bg-gray-800/50 backdrop-blur-lg",
              "border border-blue-500/20",
              "text-gray-100 placeholder-gray-400",
              "focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
              "transition-all duration-300"
            )}
          />
          <button
            type="submit"
            disabled={disabled || !message.trim()}
            className={clsx(
              "absolute right-2 p-2 rounded-lg",
              "bg-gradient-to-r from-blue-600/90 to-blue-700/90",
              "hover:from-blue-700 hover:to-blue-800",
              "disabled:from-gray-700 disabled:to-gray-800",
              "transition-all duration-300",
              "flex items-center justify-center",
              "min-w-[48px] min-h-[48px]"
            )}
          >
            <svg className="w-5 h-5 rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          </button>
        </form>
      </div>
    </div>
  );
};