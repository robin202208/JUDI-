import React from 'react';
import { ModelSelector } from '../ModelSelector';
import { ModelType } from '../../config/env';
import clsx from 'clsx';

interface WelcomeScreenProps {
  selectedModel: ModelType;
  onModelChange: (model: ModelType) => void;
  onStartChat: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  selectedModel,
  onModelChange,
  onStartChat,
}) => {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6 text-center px-4">
        <div className="relative mx-auto w-32 h-32">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl opacity-25 blur" />
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl opacity-80" />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-5xl font-bold text-white">AI</span>
          </div>
        </div>
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-2">
            欢迎使用 JUDI
          </h2>
          <p className="text-lg text-blue-200 mb-8">
            新一代人工智能大模型体验助手
          </p>
          <ModelSelector
            selectedModel={selectedModel}
            onChange={onModelChange}
          />
        </div>
        <button
          onClick={onStartChat}
          className={clsx(
            "w-full px-8 py-4 rounded-xl transition-all duration-300",
            "bg-gradient-to-r from-blue-600 to-purple-600",
            "hover:from-blue-700 hover:to-purple-700",
            "text-white font-medium shadow-lg hover:shadow-xl",
            "border border-blue-500/20"
          )}
        >
          开始对话
        </button>
      </div>
    </div>
  );
};