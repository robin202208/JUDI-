import React from 'react';
import { PlusIcon } from '@heroicons/react/24/solid';
import { Conversation } from '../types/chat';
import clsx from 'clsx';

interface SidebarProps {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  onSelectConversation: (conversation: Conversation) => void;
  onNewChat: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  currentConversation,
  onSelectConversation,
  onNewChat,
}) => {
  return (
    <div className="h-full bg-gray-900/50 border-r border-blue-500/20 flex flex-col">
      <div className="p-4">
        <button
          onClick={onNewChat}
          className={clsx(
            "w-full flex items-center justify-center gap-2 p-3 rounded-xl",
            "bg-gradient-to-r from-blue-600 to-purple-600",
            "hover:from-blue-700 hover:to-purple-700",
            "transition-all duration-300",
            "text-white font-medium",
            "border border-blue-500/20"
          )}
        >
          <PlusIcon className="w-5 h-5" />
          新对话
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {conversations.map((conversation) => (
          <button
            key={conversation.id}
            onClick={() => onSelectConversation(conversation)}
            className={clsx(
              "w-full p-3 text-left rounded-xl mb-2",
              "transition-all duration-300",
              currentConversation?.id === conversation.id
                ? "bg-blue-600/20 text-blue-300 border border-blue-500/30"
                : "hover:bg-gray-800/50 text-gray-300 border border-transparent"
            )}
          >
            <div className="text-sm font-medium truncate">{conversation.title}</div>
            <div className="text-xs text-gray-500 mt-1 truncate">
              {new Date(conversation.updatedAt).toLocaleString()}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};