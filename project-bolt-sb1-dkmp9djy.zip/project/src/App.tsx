import { v4 as uuidv4 } from 'uuid';
import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatContainer } from './components/chat/ChatContainer';
import { WelcomeScreen } from './components/welcome/WelcomeScreen';
import { useChatStore } from './store/chatStore';
import { useChat } from './hooks/useChat';
import { useLegalChat } from './hooks/useLegalChat';
import { MODELS, ModelType } from './config/env';
import clsx from 'clsx';

export function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<ModelType>(MODELS.GENERAL);
  
  const {
    conversations,
    currentConversation,
    addConversation,
    setCurrentConversation,
  } = useChatStore();

  const generalChat = useChat();
  const legalChat = useLegalChat();

  const { isLoading, sendMessage } = selectedModel === MODELS.LEGAL ? legalChat : generalChat;

  const handleNewChat = () => {
    const newConversation = {
      id: uuidv4(),
      title: selectedModel === MODELS.LEGAL ? '法律咨询' : '新对话',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    addConversation(newConversation);
    setCurrentConversation(newConversation);
    setIsSidebarOpen(false);
  };

  const handleSendMessage = async (content: string) => {
    await sendMessage(content);
  };

  return (
    <div className="flex flex-col h-[100vh] h-[calc(var(--vh,1vh)*100)] bg-gradient-to-b from-gray-900 via-gray-800 to-black text-gray-100 overflow-hidden">
      {/* Header */}
      <header className="relative z-10">
        <div className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 backdrop-blur-xl border-b border-blue-500/20 shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                  className={clsx(
                    "p-2 rounded-xl transition-all duration-300 md:hidden",
                    "bg-gradient-to-r from-blue-500/10 to-purple-500/10",
                    "hover:from-blue-500 hover:to-purple-500 hover:text-white"
                  )}
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                  </svg>
                </button>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                    JUDI 智能助手
                  </h1>
                  <p className="text-sm text-blue-300">由上海九地之下技术有限公司自主研发</p>
                </div>
              </div>
              <div className="hidden md:flex items-center gap-3">
                <div className="px-4 py-1 rounded-full bg-blue-500/10 border border-blue-400/20 text-blue-300">
                  新一代人工智能大模型
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex relative overflow-hidden">
        {/* Sidebar */}
        <div
          className={clsx(
            "fixed md:relative z-30 h-full transition-all duration-300",
            "w-[240px] md:w-[280px] backdrop-blur-lg",
            isSidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
          )}
        >
          <Sidebar
            conversations={conversations}
            currentConversation={currentConversation}
            onSelectConversation={(conv) => {
              setCurrentConversation(conv);
              setIsSidebarOpen(false);
            }}
            onNewChat={handleNewChat}
          />
        </div>

        {/* Backdrop */}
        {isSidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-20 md:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Chat Area */}
        <main className="flex-1 flex flex-col relative">
          {currentConversation ? (
            <ChatContainer
              messages={currentConversation.messages}
              isLoading={isLoading}
              selectedModel={selectedModel}
              onModelChange={setSelectedModel}
              onSendMessage={handleSendMessage}
            />
          ) : (
            <WelcomeScreen
              selectedModel={selectedModel}
              onModelChange={setSelectedModel}
              onStartChat={handleNewChat}
            />
          )}
        </main>
      </div>
    </div>
  );
}

export default App;